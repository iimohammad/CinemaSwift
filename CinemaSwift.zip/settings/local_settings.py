DATABASE = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Amir@54321!@hos8318FAR',
    'name': 'database',
    'port': '3306',
}
Network = {
    'host': '127.0.0.1',
    'port': 8080
}

log_file = 'transaction.log'
