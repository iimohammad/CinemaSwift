DATABASE = {
    'host': 'localhost',
    'user': 'question6Quera',
    'password': 'Mail1375#',
    'name': 'database',
    'port': '3306',
}
Network = {
    'host': '127.0.0.1',
    'port': 8080
}

log_file = 'transaction.log'
